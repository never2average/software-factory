#!/usr/bin/env node
/**
 * fde-mcp — one stdio MCP server that lets a LOCAL coding agent set up the whole
 * FDE control plane in the live web app: the Data Room, Connectors, Workflows,
 * and Crons.
 *
 *   node --experimental-strip-types setup/fde-mcp.mjs
 *
 * Two backends, both pointing at production:
 *   - Data Room  → the private Vercel Blob store (BLOB_READ_WRITE_TOKEN), the
 *                  SAME store the deployed agent reads.
 *   - Connectors / Workflows / Crons → the Ops Center HTTP API at FDE_OPS_URL
 *                  (default https://fde-agent.vercel.app), the SAME endpoints the
 *                  web modal uses. So "set up by a local agent" and "set up in the
 *                  browser" write to exactly the same place.
 *
 * It speaks newline-delimited JSON-RPC 2.0 on stdio (the MCP stdio transport) and
 * needs no MCP SDK. Point Claude Code at it (see setup/README.md §2).
 *
 * Config (env):
 *   BLOB_READ_WRITE_TOKEN   required for the Data Room tools (private blob store)
 *   FDE_OPS_URL             Ops API base; default https://fde-agent.vercel.app
 *   FDE_ACTOR              audit label written on every create/update/delete;
 *                          default "local-agent"
 *
 * Security: this is DIRECT write access to production. The Ops API CRUD is
 * unauthenticated by design (the browser modal is SSO-gated; the API is open),
 * so anything with FDE_OPS_URL can write it — give this to trusted machines only.
 * `record_coding_session` redacts before landing; raw `dataroom_write` does NOT.
 */
import { createInterface } from "node:readline";
import { readFile, writeFile } from "node:fs/promises";

/**
 * The Data Room tools live in the platform repo (TypeScript, loaded via
 * --experimental-strip-types). When this CLI is installed standalone from npm
 * those files are not present, so the imports are OPTIONAL: without them the
 * server still starts and serves the Connector / Workflow / Cron tools, which
 * need nothing but your `fde-login` identity. Previously these were hard
 * top-level imports, which crashed the server outright outside the repo.
 */
const dataroomLib = await import("../agent/lib/dataroom-store.ts").catch(() => null);
const sessionsLib = await import("../agent/lib/coding-sessions.ts").catch(() => null);
const createDataroomStore = dataroomLib?.createDataroomStore ?? null;
const parseClaudeTranscript = sessionsLib?.parseClaudeTranscript ?? null;
const sessionToSyncItem = sessionsLib?.sessionToSyncItem ?? null;
/** True when the data-room half of the toolset is available. */
const DATAROOM_AVAILABLE = Boolean(createDataroomStore);
const { CRED_PATH } = await import("./fde-login.mjs").catch(() => ({ CRED_PATH: null }));
import { readFile as readPkgFile } from "node:fs/promises";

const OPS_URL = (process.env.FDE_OPS_URL ?? "https://fde-agent.vercel.app").replace(/\/$/, "");
const ACTOR = process.env.FDE_ACTOR ?? "local-agent";
// How the Ops API knows who you are: your per-user Google identity from
// `fde-login` (see fde-login.mjs). There is no service-key fallback — run the
// login first. The Data Room tools use the blob token instead and need no login.
const OAUTH_CLIENT_ID =
  process.env.FDE_OAUTH_CLIENT_ID ??
  "865110163807-dsiua8j7v253dqngcccechjbc4a14scp.apps.googleusercontent.com";
// Baked-in desktop-client secret — non-confidential by design (see fde-login.mjs).
const OAUTH_CLIENT_SECRET =
  process.env.FDE_OAUTH_CLIENT_SECRET ?? "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";

/**
 * A live @onfinance.in ID token from the stored login, or null. Cached in memory
 * and refreshed a minute before it expires, so most calls pay nothing.
 */
let cachedIdToken = null;
let cachedExp = 0;
async function userIdToken() {
  const now = Date.now() / 1000;
  if (cachedIdToken && cachedExp - now > 60) return cachedIdToken;
  let creds;
  try {
    creds = JSON.parse(await readFile(CRED_PATH, "utf8"));
  } catch {
    return null;
  }
  const stored = creds.id_token;
  const exp = stored ? JSON.parse(Buffer.from(stored.split(".")[1], "base64url").toString()).exp : 0;
  if (stored && exp - now > 60) {
    cachedIdToken = stored;
    cachedExp = exp;
    return stored;
  }
  // Refresh. Google requires the client secret even for desktop refresh.
  if (!creds.refresh_token || !OAUTH_CLIENT_SECRET) return stored ?? null;
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: OAUTH_CLIENT_ID,
      client_secret: OAUTH_CLIENT_SECRET,
      refresh_token: creds.refresh_token,
      grant_type: "refresh_token",
    }),
  });
  const t = await res.json().catch(() => ({}));
  if (!res.ok || !t.id_token) return stored ?? null;
  cachedIdToken = t.id_token;
  cachedExp = JSON.parse(Buffer.from(t.id_token.split(".")[1], "base64url").toString()).exp;
  await writeFile(CRED_PATH, JSON.stringify({ ...creds, id_token: t.id_token }, null, 2), {
    mode: 0o600,
  }).catch(() => {});
  return cachedIdToken;
}

/** The bearer for an Ops API call: your Google identity. Null if not logged in. */
async function opsBearer() {
  return await userIdToken();
}
const hasBlob = Boolean(process.env.BLOB_READ_WRITE_TOKEN) && DATAROOM_AVAILABLE;
const store = hasBlob ? createDataroomStore() : null;
const backend = store?.backend?.kind ?? "none";

// ------------------------------------------------------------ HTTP to the Ops API

async function api(method, path, body) {
  const bearer = await opsBearer();
  if (!bearer) {
    throw new Error(
      "Not signed in. Ask the user to run `npx -p @delivery-agents/cli fde-login` in a terminal" +
        " (an interactive browser sign-in you cannot do yourself), then retry.",
    );
  }
  const res = await fetch(`${OPS_URL}${path}`, {
    method,
    headers: {
      "content-type": "application/json",
      ...(bearer ? { authorization: `Bearer ${bearer}` } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(30_000),
  });
  const text = await res.text();
  let parsed;
  try {
    parsed = text ? JSON.parse(text) : {};
  } catch {
    parsed = { raw: text };
  }
  if (!res.ok) throw new Error(parsed.error ?? `HTTP ${res.status} from ${path}`);
  return parsed;
}

/** The Data Room tools require the REAL blob store, not the local-dir fallback. */
function requireBlob() {
  if (!store || backend !== "vercel-blob") {
    throw new Error(
      "Data Room tools need BLOB_READ_WRITE_TOKEN set to the production blob store." +
        " Without it these would write a local folder, not the live data room.",
    );
  }
  return store;
}

/**
 * The data room, reachable two ways:
 *   - the Ops API under your `fde-login` identity (the default — works from a
 *     plain npm install, keeps the production blob token off your machine, and
 *     is org-scoped + audited server-side);
 *   - the blob store directly, when you're inside the platform repo WITH
 *     BLOB_READ_WRITE_TOKEN set (faster, and what the deployed agent uses).
 *
 * Without this the data-room tools were repo-only, so the published CLI could
 * not configure a data room at all.
 */

/**
 * The workspace these tools act on.
 *
 * NOT simply `items[0]`: a platform admin's /api/ops/orgs lists EVERY workspace,
 * so the first row can belong to someone else entirely — inviting into it would
 * be a cross-tenant mistake. Prefer the org whose id matches the signed-in
 * user's own email domain, and only fall back to the single row when there is
 * exactly one.
 */
async function myWorkspace() {
  const { items = [] } = await api("GET", "/api/ops/orgs");
  if (items.length === 0) {
    throw new Error(`No workspace yet. Open ${OPS_URL}/onboard in a browser to create one.`);
  }
  if (items.length === 1) return items[0];
  const email = (await whoami())?.email ?? "";
  const domain = email.split("@")[1]?.split(".")[0]?.toLowerCase();
  const mine = domain && items.find((o) => o.orgId.toLowerCase().includes(domain));
  if (mine) return mine;
  throw new Error(
    `You can see ${items.length} workspaces (${items.map((o) => o.orgId).join(", ")}). ` +
      "Ambiguous — say which one you mean.",
  );
}

/** Claims from the current ID token, or null when signed out. */
async function whoami() {
  const token = await userIdToken();
  if (!token) return null;
  try {
    return JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
  } catch {
    return null;
  }
}

/** Fold the agent's stated reason + citations into the write request. */
function cite({ rationale, sources } = {}) {
  const note = [rationale, sources?.length ? `sources: ${sources.join(", ")}` : null]
    .filter(Boolean)
    .join(" · ");
  return note ? { rationale: note.slice(0, 500) } : {};
}

const dataroom = {
  via: hasBlob ? "blob" : "ops-api",
  async list(prefix = "") {
    if (hasBlob) return await requireBlob().list(prefix);
    const q = prefix ? `?prefix=${encodeURIComponent(prefix)}` : "";
    return (await api("GET", `/api/ops/dataroom${q}`)).paths ?? [];
  },
  async read(path) {
    if (hasBlob) return await requireBlob().read(path);
    const r = await api("GET", `/api/ops/dataroom?path=${encodeURIComponent(path)}`);
    if (!r.found) return null;
    return r.content ?? JSON.stringify(r.records ?? [], null, 2);
  },
  async readJsonl(path) {
    if (hasBlob) return await requireBlob().readJsonl(path);
    const r = await api("GET", `/api/ops/dataroom?path=${encodeURIComponent(path)}`);
    return r.found ? (r.records ?? []) : [];
  },
  // `meta` (rationale + sources) rides along so the server audit records WHY a
  // file changed and where the content came from, not just that it changed.
  async write(path, content, meta = {}) {
    if (hasBlob) return await requireBlob().write(path, content);
    await api("POST", "/api/ops/dataroom", { path, content, ...cite(meta) });
  },
  async appendJsonl(path, records, meta = {}) {
    if (hasBlob) return await requireBlob().appendJsonl(path, records);
    const body = records.map((r) => JSON.stringify(r)).join("\n");
    await api("POST", "/api/ops/dataroom", { path, content: body, append: true, ...cite(meta) });
    return records.length;
  },
};

const json = (v) => JSON.stringify(v, null, 2);

/** The eve subagents the orchestrator can delegate to. */
const SUBAGENT_IDS = [
  "research", "customer-context", "configuration", "deployment", "data-migration",
  "evals", "workflow-author", "app-author", "follow-ups", "browser",
];

// -------------------------------------------------------------------- the tools

const TOOLS = [
  // ---------------------------------------------------------------- Orientation
  {
    name: "fde_status",
    description:
      "START HERE. Who you are signed in as, which workspace you're operating on, what's already set up (connectors/workflows/crons), and the concrete next steps. Call this before anything else — every other tool depends on the identity and workspace it reports.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const out = {
        signedIn: false,
        identity: null,
        workspace: null,
        dataRoom: hasBlob ? "ready (direct blob)" : "ready (via Ops API, as you)",
        opsApi: OPS_URL,
        contents: null,
        nextSteps: [],
      };

      // Identity comes from the stored fde-login session.
      const token = await userIdToken();
      if (!token) {
        out.nextSteps.push(
          "Not signed in. Run `npx -p @delivery-agents/cli fde-login` in a terminal, then call fde_status again.",
        );
        return json(out);
      }
      try {
        const claims = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
        out.signedIn = true;
        out.identity = { email: claims.email ?? "unknown", domain: claims.hd ?? null };
      } catch {
        out.identity = { email: "unknown", domain: null };
      }

      // Which workspace does this identity operate on?
      try {
        const { items = [] } = await api("GET", "/api/ops/orgs");
        if (items.length === 0) {
          out.nextSteps.push(
            `No workspace yet. Open ${OPS_URL}/onboard in a browser to create one, then call fde_status again.`,
          );
          return json(out);
        }
        const w = items[0];
        out.workspace = { id: w.orgId, name: w.name, role: w.role };
      } catch (e) {
        out.nextSteps.push(`Could not read your workspace: ${e.message}`);
        return json(out);
      }

      // What already exists, so the agent doesn't propose duplicates.
      const count = async (path) => {
        try {
          return ((await api("GET", path)).items ?? []).length;
        } catch {
          return null;
        }
      };
      const [connectors, workflows, crons] = await Promise.all([
        count("/api/ops/connectors"),
        count("/api/ops/workflows"),
        count("/api/ops/schedules"),
      ]);
      out.contents = { connectors, workflows, crons };

      if (!connectors) out.nextSteps.push("No connectors yet — `connector_create` to add an ingestion source.");
      if (!workflows) out.nextSteps.push("No workflows yet — `workflow_create`, then `workflow_set_script`.");
      if (!crons) out.nextSteps.push("No schedules yet — `cron_create` to run a workflow on a cadence.");
      if (out.nextSteps.length === 0) {
        out.nextSteps.push("Workspace is set up. List connectors/workflows/crons to see what to change.");
      }
      return json(out);
    },
  },
  // -------------------------------------------------- Connector secrets (creds)
  {
    name: "connector_secrets",
    description:
      "What a connector NEEDS to work vs what it actually HAS. Shows each required secret, its purpose, whether it is optional, whether a value is stored, and whether the running agent sees it. Call this after connector_create — a connector without its secrets is a dead shell.",
    inputSchema: {
      type: "object",
      properties: { id: { type: "string", description: "Connector id from connector_list." } },
      required: ["id"],
    },
    handler: async ({ id }) => json(await api("GET", `/api/ops/connectors/${id}/secrets`)),
  },
  {
    name: "connector_secret_set",
    description:
      "Store one secret for a connector (e.g. SLACK_BOT_TOKEN, GITHUB_TOKEN). The value is encrypted per-workspace and never returned — reads only ever show a last-4 hint. NEVER echo a secret back, and never write one into a data-room file. IMPORTANT: stored is not the same as LIVE — the running agent reads its own environment, so a stored secret only takes effect once it is promoted there; connector_secrets shows both columns, so report `live` when the human asks whether a connector works.",
    inputSchema: {
      type: "object",
      properties: {
        id: { type: "string" },
        name: { type: "string", description: "Secret name from connector_secrets." },
        value: { type: "string" },
      },
      required: ["id", "name", "value"],
    },
    handler: async ({ id, name, value }) => {
      await api("PUT", `/api/ops/connectors/${id}/secrets`, { name, value, actor: ACTOR });
      return `stored ${name} for connector ${id} (value not echoed)`;
    },
  },
  {
    name: "connector_secret_delete",
    description: "Remove one stored secret from a connector.",
    inputSchema: {
      type: "object",
      properties: { id: { type: "string" }, name: { type: "string" } },
      required: ["id", "name"],
    },
    handler: async ({ id, name }) => {
      await api("DELETE", `/api/ops/connectors/${id}/secrets`, { name, actor: ACTOR });
      return `removed ${name} from connector ${id}`;
    },
  },
  // ---------------------------------------------------------------- People
  {
    name: "people_list",
    description: "Everyone in the workspace: roster entries (name, team, manager) merged with workspace members and their roles.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const [roster, ws] = await Promise.all([
        api("GET", "/api/ops/roster").catch(() => ({ items: [] })),
        myWorkspace(),
      ]);
      const orgId = ws.orgId;
      const members = await api("GET", `/api/ops/orgs/${orgId}/members`).catch(() => ({ items: [] }));
      const roleOf = new Map((members.items ?? []).map((m) => [m.email.toLowerCase(), m.role]));
      const rows = new Map();
      for (const p of roster.items ?? []) {
        rows.set(p.email.toLowerCase(), { ...p, role: roleOf.get(p.email.toLowerCase()) ?? null });
      }
      for (const m of members.items ?? []) {
        const k = m.email.toLowerCase();
        if (!rows.has(k)) rows.set(k, { email: m.email, name: null, team: null, role: m.role });
      }
      return json({ orgId, people: [...rows.values()] });
    },
  },
  {
    name: "people_invite",
    description:
      "Invite someone to the workspace by email and get a shareable invite link back. Admin/owner only, and only an owner may invite another owner — a 403 here means your role is too low, not that the tool is broken.",
    inputSchema: {
      type: "object",
      properties: {
        email: { type: "string" },
        role: { type: "string", enum: ["owner", "admin", "engineer", "member"] },
        confirm: { type: "boolean", description: "Omit to PREVIEW the invite email; pass true to actually send it." },
      },
      required: ["email"],
    },
    handler: async ({ email, role = "member", confirm = false }) => {
      const { orgId, name } = await myWorkspace();
      // Preview first: an invite is an email to a real person, so the human sees
      // exactly who and what before it leaves.
      if (!confirm) {
        const { preview } = await api("POST", `/api/ops/orgs/${orgId}/invites`, {
          rows: [{ email, role }],
          preview: true,
        });
        return json({
          preview: true,
          sent: false,
          workspace: `${name} (${orgId})`,
          invite: { email, role },
          email: preview,
          next: "Show this to the human. Only re-call with confirm:true once they approve.",
        });
      }
      const res = await api("POST", `/api/ops/orgs/${orgId}/invites`, { rows: [{ email, role }] });
      return json(res.sent ?? res);
    },
  },
  {
    name: "people_set_role",
    description: "Change a member's workspace role, or add them to the workspace. Admin/owner only; only an owner can grant or change `owner`.",
    inputSchema: {
      type: "object",
      properties: {
        email: { type: "string" },
        role: { type: "string", enum: ["owner", "admin", "engineer", "member"] },
      },
      required: ["email", "role"],
    },
    handler: async ({ email, role }) => {
      const { orgId } = await myWorkspace();
      const members = await api("GET", `/api/ops/orgs/${orgId}/members`);
      const exists = (members.items ?? []).some((m) => m.email.toLowerCase() === email.toLowerCase());
      if (exists) {
        await api("PATCH", `/api/ops/orgs/${orgId}/members/${encodeURIComponent(email)}`, { role });
        return `${email} is now ${role}`;
      }
      await api("POST", `/api/ops/orgs/${orgId}/members`, { email, role });
      return `added ${email} as ${role}`;
    },
  },
  // ---------------------------------------------------------------- Subagents
  {
    name: "agent_list",
    description: "The specialist subagents the orchestrator delegates to, with their per-workspace state: paused or active, and any custom instructions.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const { items = [] } = await api("GET", "/api/ops/agent-configs").catch(() => ({ items: [] }));
      const cfg = new Map(items.map((i) => [i.agentKey, i]));
      return json(
        SUBAGENT_IDS.map((key) => ({
          agent: key,
          paused: cfg.get(key)?.paused ?? false,
          instructions: cfg.get(key)?.instructions ?? null,
        })),
      );
    },
  },
  {
    name: "agent_configure",
    description:
      "Tune a subagent for your use case: pause/resume it (a paused agent is never delegated to) and give it standing instructions injected whenever it runs. Admin/owner only.",
    inputSchema: {
      type: "object",
      properties: {
        agent: { type: "string", description: "One of: " + SUBAGENT_IDS.join(", ") },
        paused: { type: "boolean" },
        instructions: { type: "string", description: "Standing instructions; pass an empty string to clear." },
      },
      required: ["agent"],
    },
    handler: async ({ agent, paused, instructions }) => {
      if (!SUBAGENT_IDS.includes(agent)) {
        throw new Error(`Unknown subagent "${agent}". One of: ${SUBAGENT_IDS.join(", ")}`);
      }
      const body = { agentKey: agent };
      if (paused !== undefined) body.paused = paused;
      if (instructions !== undefined) body.instructions = instructions || null;
      return json(await api("PUT", "/api/ops/agent-configs", body));
    },
  },
  // -------------------------------------------------------------------- Apps
  {
    name: "app_list",
    description: "Living documents the agent regenerates on a cadence (dashboards, digests, QBRs).",
    inputSchema: { type: "object", properties: {} },
    handler: async () => json((await api("GET", "/api/ops/apps")).items),
  },
  {
    name: "app_create",
    description:
      "Create an app — a living document regenerated on a cadence. sourceKind 'workflow' runs a workflow; 'prompt' runs a prompt (optionally via a named subagent). refreshCron sets the cadence.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        description: { type: "string" },
        sourceKind: { type: "string", enum: ["workflow", "prompt"] },
        workflow: { type: "string", description: "Workflow name when sourceKind is 'workflow'." },
        prompt: { type: "string", description: "The prompt when sourceKind is 'prompt'." },
        subagent: { type: "string" },
        customerId: { type: "string" },
        refreshCron: { type: "string", description: "e.g. '0 7 * * 1-5'" },
      },
      required: ["name", "description", "sourceKind"],
    },
    handler: async (a) => json(await api("POST", "/api/ops/apps", { ...a, createdBy: ACTOR })),
  },
  // ------------------------------------------------- Delivery (sprints/rollouts)
  {
    name: "sprint_list",
    description: "Sprints (cycles): name, window, and state.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => json((await api("GET", "/api/ops/cycles")).items),
  },
  {
    name: "sprint_create",
    description: "Create a sprint (cycle) with a name and an ISO start/end window.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        startsAt: { type: "string", description: "ISO date/time" },
        endsAt: { type: "string", description: "ISO date/time" },
      },
      required: ["name", "startsAt", "endsAt"],
    },
    handler: async ({ name, startsAt, endsAt }) =>
      json(await api("POST", "/api/ops/cycles", { name, startsAt, endsAt, createdBy: ACTOR })),
  },
  {
    name: "implementation_upsert",
    description:
      "Create or update a customer rollout: stage (scoping/configuration/integration/uat/go-live), risk, progress and owner. Keyed on customerId.",
    inputSchema: {
      type: "object",
      properties: {
        customerId: { type: "string" },
        implementationStage: { type: "string" },
        implementationRiskLevel: { type: "string" },
        implementationProgressPct: { type: "number" },
        implementationOwnerEmail: { type: "string" },
        displayName: { type: "string" },
      },
      required: ["customerId"],
    },
    handler: async (a) => json(await api("POST", "/api/ops/implementations", a)),
  },
  {
    name: "deployment_upsert",
    description: "Create or update a deployment record: environment, region, version, release + health status, owner.",
    inputSchema: {
      type: "object",
      properties: {
        customerId: { type: "string" },
        deploymentId: { type: "string" },
        environment: { type: "string" },
        region: { type: "string" },
        deployedVersion: { type: "string" },
        releaseStatus: { type: "string" },
        healthStatus: { type: "string" },
        deployOwnerEmail: { type: "string" },
        displayName: { type: "string" },
      },
      required: ["customerId"],
    },
    handler: async (a) => json(await api("POST", "/api/ops/deployments", a)),
  },
  // ------------------------------------------------------------ Tasks & tickets
  {
    name: "ticket_list",
    description: "Customer tickets — use these ids to link a task to the ticket it came from.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => json((await api("GET", "/api/ops/tickets")).items),
  },
  {
    name: "task_list",
    description: "The team's TODOs: status, assignee, sprint, container and any linked object.",
    inputSchema: {
      type: "object",
      properties: { includeDone: { type: "boolean" } },
      required: [],
    },
    handler: async ({ includeDone = false }) =>
      json((await api("GET", `/api/ops/todos?includeDone=${includeDone ? "true" : "false"}`)).items),
  },
  {
    name: "task_create",
    description:
      "Create a task, optionally LINKED to the ticket it came from (linkType:'ticket', linkId: the ticket id from ticket_list) and filed under a sprint (cycleId) or a deployment/implementation (containerType + containerId).",
    inputSchema: {
      type: "object",
      properties: {
        title: { type: "string" },
        notes: { type: "string" },
        status: { type: "string", enum: ["backlog", "open", "in_progress", "blocked", "done", "cancelled"] },
        priority: { type: "string", enum: ["low", "normal", "high"] },
        dueAt: { type: "string", description: "ISO-8601" },
        assignee: { type: "string" },
        cycleId: { type: "string", description: "Sprint id from sprint_list." },
        linkType: { type: "string", enum: ["ticket", "customer", "app", "cron", "workflow", "chat"] },
        linkId: { type: "string" },
        linkLabel: { type: "string" },
        containerType: { type: "string", enum: ["deployment", "implementation"] },
        containerId: { type: "string" },
      },
      required: ["title"],
    },
    handler: async (a) => json(await api("POST", "/api/ops/todos", a)),
  },
  // ------------------------------------------------------------------ Data Room
  {
    name: "dataroom_structure",
    description:
      "READ THIS BEFORE WRITING TO THE DATA ROOM. Returns dm.md — the canonical folder/file contract (Customers/ Platform/ Deployments/ Solutions/ Implementation/ Tickets/ People/) showing exactly where each artifact belongs and which files are .jsonl streams. Paths must start with one of those domains and have at least two segments; a root-level file is rejected.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const url = new URL("./dm.md", import.meta.url);
      const spec = await readPkgFile(url, "utf8").catch(() => null);
      return spec ?? "dm.md is not bundled with this install.";
    },
  },
  {
    name: "dataroom_list",
    description: "List object paths in the data-room blob store under a prefix (e.g. 'Customers/'). Empty prefix lists everything.",
    inputSchema: { type: "object", properties: { prefix: { type: "string" } } },
    handler: async ({ prefix = "" }) => (await dataroom.list(prefix)).join("\n") || "(empty)",
  },
  {
    name: "dataroom_read",
    description: "Read one object's full text from the data room. '(not found)' if absent.",
    inputSchema: { type: "object", properties: { path: { type: "string" } }, required: ["path"] },
    handler: async ({ path }) => (await dataroom.read(path)) ?? "(not found)",
  },
  {
    name: "dataroom_read_jsonl",
    description: "Read a .jsonl data-room object and return its records as a JSON array.",
    inputSchema: { type: "object", properties: { path: { type: "string" } }, required: ["path"] },
    handler: async ({ path }) => json(await dataroom.readJsonl(path)),
  },
  {
    name: "dataroom_write",
    description:
      "Write a file to the data room. HUMAN-IN-THE-LOOP: without `confirm:true` this WRITES NOTHING — it returns a preview (path, whether it overwrites, size, the content itself). Show that preview to the human, explain what you are writing and where each fact came from, and only call again with confirm:true once they approve. Always pass `rationale` and `sources`; they are recorded in the audit trail.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "Canonical dm.md path (see dataroom_structure)." },
        content: { type: "string" },
        confirm: { type: "boolean", description: "Must be true to actually write. Omit to preview." },
        rationale: { type: "string", description: "Why this file, in one line — shown to the human and audited." },
        sources: {
          type: "array",
          items: { type: "string" },
          description: "Where the content came from (data-room paths, URLs, the person who told you).",
        },
      },
      required: ["path", "content"],
    },
    handler: async ({ path, content, confirm = false, rationale, sources = [] }) => {
      const existing = await dataroom.read(path).catch(() => null);
      if (!confirm) {
        return json({
          preview: true,
          wrote: false,
          path,
          action: existing === null ? "create" : "OVERWRITE an existing file",
          bytes: content.length,
          rationale: rationale ?? "(none given — say why before asking the human)",
          sources: sources.length ? sources : ["(none cited — cite where this came from)"],
          replaces: existing === null ? null : `${existing.slice(0, 400)}${existing.length > 400 ? "…" : ""}`,
          content,
          next: "Show this to the human verbatim. Only re-call with confirm:true once they approve.",
        });
      }
      await dataroom.write(path, content, { rationale, sources });
      return json({
        wrote: true,
        path,
        bytes: content.length,
        action: existing === null ? "created" : "overwrote",
        rationale: rationale ?? null,
        sources,
      });
    },
  },
  {
    name: "dataroom_append_jsonl",
    description:
      "Append records to a .jsonl data-room stream. HUMAN-IN-THE-LOOP: without `confirm:true` this returns a preview of exactly what would be appended — show it to the human and get approval first. Pass `rationale` and `sources`.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        records: { type: "array", items: { type: "object" } },
        confirm: { type: "boolean", description: "Must be true to actually append." },
        rationale: { type: "string" },
        sources: { type: "array", items: { type: "string" } },
      },
      required: ["path", "records"],
    },
    handler: async ({ path, records, confirm = false, rationale, sources = [] }) => {
      if (!Array.isArray(records)) throw new Error("records must be a JSON array");
      if (!confirm) {
        return json({
          preview: true,
          wrote: false,
          path,
          action: `append ${records.length} record(s)`,
          rationale: rationale ?? "(none given)",
          sources: sources.length ? sources : ["(none cited)"],
          records,
          next: "Show this to the human. Only re-call with confirm:true once they approve.",
        });
      }
      const n = await dataroom.appendJsonl(path, records, { rationale, sources });
      return json({ wrote: true, path, appended: n, rationale: rationale ?? null, sources });
    },
  },
  {
    name: "record_coding_session",
    description: "Redact a Claude Code .jsonl transcript and land it as a Deployments/syncs/claude record for a customer. Secrets are stripped before anything is stored.",
    inputSchema: {
      type: "object",
      properties: {
        transcript: { type: "string" },
        customerId: { type: "string" },
        date: { type: "string", description: "YYYY-MM-DD; defaults to today (UTC)." },
      },
      required: ["transcript", "customerId"],
    },
    handler: async ({ transcript, customerId, date }) => {
      const session = parseClaudeTranscript(transcript, `mcp-${customerId}`);
      if (!session) return "no session could be parsed from that transcript";
      const day = date ?? new Date().toISOString().slice(0, 10);
      const path = `Deployments/syncs/claude/${customerId}/${day}.jsonl`;
      const n = await requireBlob().appendJsonl(path, [sessionToSyncItem(session)]);
      return `landed ${n} redacted session → ${path} (repo: ${session.repo ?? "?"}, ${session.userTurns} turns)`;
    },
  },

  // ------------------------------------------------------------------ Connectors
  {
    name: "connector_list",
    description: "List all connectors, with id, name, kind, access, synced workflows and health.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => json((await api("GET", "/api/ops/connectors")).items),
  },
  {
    name: "connector_create",
    description:
      "Create a connector. Two shapes:\n" +
      "(1) BUILT-IN — kind is one of github, slack, gmail, granola, exa, pagerduty, system_of_record. Its credential contract is fixed in code; call connector_secrets to see it.\n" +
      "(2) BRING-YOUR-OWN — any other kind (use 'mcp'). Give `endpointUrl` (the https MCP server), `requiredSecrets` (the credentials it needs, UPPER_SNAKE_CASE, each with a purpose) and `authSecretName` (which of those is the bearer token). The agent then discovers and calls that server's tools at runtime — no redeploy, no code change. Without endpointUrl and requiredSecrets a custom connector is only a note in a list: nothing can authenticate to it.\n" +
      "access is read|write|read_write; lands is where its sync writes in the data room; synced is the workflow names it feeds.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        kind: { type: "string", description: "Built-in slug, or 'mcp' for your own server." },
        access: { type: "string", enum: ["read", "write", "read_write"] },
        lands: { type: "string" },
        detail: { type: "string" },
        synced: { type: "array", items: { type: "string" } },
        notifyEmails: { type: "array", items: { type: "string" } },
        enabled: { type: "boolean" },
        endpointUrl: {
          type: "string",
          description: "Bring-your-own only: the https MCP endpoint, e.g. https://mcp.linear.app/mcp. Must be public https — private and loopback addresses are refused.",
        },
        requiredSecrets: {
          type: "array",
          description: "Bring-your-own only: the credential contract. The secrets route accepts these names and no others.",
          items: {
            type: "object",
            properties: {
              name: { type: "string", description: "UPPER_SNAKE_CASE, e.g. LINEAR_API_KEY." },
              purpose: { type: "string", description: "What breaks without it, in one line." },
              optional: { type: "boolean" },
            },
            required: ["name", "purpose"],
          },
        },
        authSecretName: {
          type: "string",
          description: "Bring-your-own only: which required secret is sent as the Bearer token.",
        },
      },
      required: ["name", "kind", "access"],
    },
    handler: async (a) => json((await api("POST", "/api/ops/connectors", { ...a, createdBy: ACTOR })).item),
  },
  {
    name: "connector_update",
    description: "Update fields on a connector by id (name, access, lands, detail, synced, notifyEmails, notifyWhen, enabled, and for a bring-your-own connector endpointUrl / requiredSecrets / authSecretName).",
    inputSchema: {
      type: "object",
      properties: { id: { type: "string" }, patch: { type: "object", description: "Fields to change." } },
      required: ["id", "patch"],
    },
    handler: async ({ id, patch }) => json((await api("PATCH", `/api/ops/connectors/${id}`, { ...patch, actor: ACTOR })).item),
  },
  {
    name: "connector_delete",
    description: "Delete a connector by id.",
    inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] },
    handler: async ({ id }) => json(await api("DELETE", `/api/ops/connectors/${id}`, { actor: ACTOR })),
  },

  // ------------------------------------------------------------------- Workflows
  {
    name: "workflow_list",
    description: "List all workflows, with id, name, description, trigger, enabled, and whether they have a script.",
    inputSchema: { type: "object", properties: {} },
    handler: async () =>
      json(
        (await api("GET", "/api/ops/workflows")).items.map((w) => ({
          id: w.id,
          name: w.name,
          trigger: w.trigger,
          enabled: w.enabled,
          hasScript: Boolean(w.script?.trim()),
          description: w.description,
        })),
      ),
  },
  {
    name: "workflow_create",
    description: "Create a workflow (name + description required). trigger defaults to 'on delegation'. Set the TypeScript with workflow_set_script afterwards.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        description: { type: "string" },
        trigger: { type: "string" },
        customerId: { type: "string" },
        steps: { type: "array", items: { type: "string" } },
        enabled: { type: "boolean" },
      },
      required: ["name", "description"],
    },
    handler: async (a) => json((await api("POST", "/api/ops/workflows", { ...a, createdBy: ACTOR })).item),
  },
  {
    name: "workflow_set_script",
    description:
      "Set a workflow's TypeScript by id. The script is validated server-side on save (sandbox contract: only agent/parallel/pipeline/phase/log/args; no imports, no host access). A bad script is rejected with the offending line — write it, read the error, fix it.",
    inputSchema: {
      type: "object",
      properties: { id: { type: "string" }, script: { type: "string" } },
      required: ["id", "script"],
    },
    handler: async ({ id, script }) => {
      const { item } = await api("PATCH", `/api/ops/workflows/${id}`, { script, actor: ACTOR });
      return `saved script for "${item.name}" (${script.split("\n").length} lines)`;
    },
  },
  {
    name: "workflow_update",
    description: "Update fields on a workflow by id (name, description, trigger, customerId, steps, instructions, instructionsEnabled, enabled).",
    inputSchema: {
      type: "object",
      properties: { id: { type: "string" }, patch: { type: "object" } },
      required: ["id", "patch"],
    },
    handler: async ({ id, patch }) => json((await api("PATCH", `/api/ops/workflows/${id}`, { ...patch, actor: ACTOR })).item),
  },
  {
    name: "workflow_delete",
    description: "Delete a workflow by id.",
    inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] },
    handler: async ({ id }) => json(await api("DELETE", `/api/ops/workflows/${id}`, { actor: ACTOR })),
  },

  // ----------------------------------------------------------------------- Crons
  {
    name: "cron_list",
    description: "List all custom schedules (crons), with id, name, prompt, cron/everyMinutes, channelId and enabled.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => json((await api("GET", "/api/ops/schedules")).items),
  },
  {
    name: "cron_create",
    description: "Create a scheduled run (name + prompt required). Give EITHER cron (a 5-field expression) OR everyMinutes. channelId is an optional Slack channel to post into.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        prompt: { type: "string" },
        cron: { type: "string" },
        everyMinutes: { type: "number" },
        channelId: { type: "string" },
        customerId: { type: "string" },
        enabled: { type: "boolean" },
      },
      required: ["name", "prompt"],
    },
    handler: async (a) => json((await api("POST", "/api/ops/schedules", { ...a, createdBy: ACTOR })).item),
  },
  {
    name: "cron_update",
    description: "Update fields on a schedule by id (name, prompt, cron, everyMinutes, channelId, customerId, enabled).",
    inputSchema: {
      type: "object",
      properties: { id: { type: "string" }, patch: { type: "object" } },
      required: ["id", "patch"],
    },
    handler: async ({ id, patch }) => json((await api("PATCH", `/api/ops/schedules/${id}`, { ...patch, actor: ACTOR })).item),
  },
  {
    name: "cron_delete",
    description: "Delete a schedule by id.",
    inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] },
    handler: async ({ id }) => json(await api("DELETE", `/api/ops/schedules/${id}`, { actor: ACTOR })),
  },
];

const TOOL_MAP = new Map(TOOLS.map((t) => [t.name, t]));

// ------------------------------------------------------------ JSON-RPC plumbing

function send(msg) {
  process.stdout.write(`${JSON.stringify(msg)}\n`);
}
const reply = (id, result) => send({ jsonrpc: "2.0", id, result });
const fail = (id, code, message) => send({ jsonrpc: "2.0", id, error: { code, message } });

async function handle(msg) {
  const { id, method, params } = msg;

  if (method === "initialize") {
    return reply(id, {
      protocolVersion: params?.protocolVersion ?? "2024-11-05",
      capabilities: { tools: {} },
      serverInfo: { name: "fde-control", version: "0.3.0" },
      instructions: [
        "Delivered control plane — operate a real FDE workspace from this editor.",
        "",
        "**Call `fde_status` first.** It reports who you're signed in as, which workspace",
        "you're operating on, what already exists, and the concrete next step. Every other",
        "tool depends on that identity; without it they fail with 'Not signed in'.",
        "",
        "What you can do here:",
        "- **Connectors** — ingestion sources (`connector_*`). `connector_secrets` shows what one",
        "  NEEDS vs HAS; `connector_secret_set` stores a credential. A connector without its",
        "  secrets is a dead shell. Any kind we don't ship is a BRING-YOUR-OWN connector: give it",
        "  an `endpointUrl` + `requiredSecrets` and the agent calls that MCP server directly.",
        "- **People** — `people_list`, `people_invite`, `people_set_role`.",
        "- **Subagents** — `agent_list` / `agent_configure` to pause one or give it standing",
        "  instructions for this workspace.",
        "- **Workflows** — durable scripts the orchestrator runs (`workflow_*`; create it,",
        "  then `workflow_set_script`).",
        "- **Crons** — schedules that run a workflow on a cadence (`cron_*`).",
        "- **Apps** — living documents regenerated on a cadence (`app_*`).",
        "- **Delivery** — `sprint_*`, `implementation_upsert`, `deployment_upsert`.",
        "- **Work** — `task_*` and `ticket_list`; link a task to its ticket with",
        "  `linkType:'ticket'` + `linkId`.",
        "- **Data room** — read/write the customer document store (`dataroom_*`). Call",
        "  `dataroom_structure` FIRST: it returns dm.md, the folder contract every path must obey.",
        "",
        `These write to LIVE PRODUCTION at ${OPS_URL} — the same data the web console shows.`,
        "There is no sandbox. Read before you write, prefer updating over recreating, and",
        "confirm destructive changes (`*_delete`) with the user first.",
        "",
        "## Ask before you write",
        "",
        "Writes to the data room and invites to people PREVIEW by default: called without",
        "`confirm:true` they return exactly what would happen and change nothing. That preview",
        "is for the HUMAN, not for you — show it to them verbatim, in your own message, and wait.",
        "Along with it state:",
        "- **What** — the path and whether it creates or OVERWRITES (the preview says which).",
        "- **Why** — pass `rationale`; it is written into the audit trail, so the workspace",
        "  later says why a file changed and not merely that it did.",
        "- **Where it came from** — pass `sources`: the files you read, the URLs, the person who",
        "  told you. Content you inferred rather than sourced must be labelled as inferred.",
        "Only re-call with `confirm:true` after they say yes. Never pass `confirm:true` on the",
        "first call to save a round trip — that is the entire safeguard.",
        "",
        "Never write a credential into a data-room file. Secrets go through",
        "`connector_secret_set`, which encrypts them and never reads them back.",
        "",
        "If a tool says you're not signed in, tell the user to run",
        "`npx -p @delivery-agents/cli fde-login` — you cannot complete that browser flow yourself.",
      ].join("\n"),
    });
  }
  if (method === "notifications/initialized" || id === undefined) return;

  if (method === "tools/list") {
    return reply(id, {
      // Outside the platform repo the data-room modules are absent, so those
      // tools are withheld rather than advertised and then failing on call.
      // dataroom_* work over the Ops API, so they ship everywhere. Only
      // record_coding_session needs the repo (its redactor lives there).
      tools: TOOLS.filter((t) => DATAROOM_AVAILABLE || t.name !== "record_coding_session")
        .map(({ name, description, inputSchema }) => ({ name, description, inputSchema })),
    });
  }

  if (method === "tools/call") {
    const tool = TOOL_MAP.get(params?.name);
    if (!tool) return fail(id, -32602, `unknown tool: ${params?.name}`);
    try {
      const text = await tool.handler(params.arguments ?? {});
      return reply(id, { content: [{ type: "text", text: String(text) }] });
    } catch (e) {
      return reply(id, {
        content: [{ type: "text", text: `error: ${e instanceof Error ? e.message : String(e)}` }],
        isError: true,
      });
    }
  }

  if (method === "ping") return reply(id, {});
  return fail(id, -32601, `method not found: ${method}`);
}

process.stderr.write(
  `[fde-mcp] ready — Data Room blob: ${backend}, Ops API: ${OPS_URL}, ${TOOLS.length} tools\n`,
);
const rl = createInterface({ input: process.stdin });
for await (const line of rl) {
  const trimmed = line.trim();
  if (!trimmed) continue;
  let msg;
  try {
    msg = JSON.parse(trimmed);
  } catch {
    continue;
  }
  handle(msg).catch((e) => {
    if (msg?.id !== undefined) fail(msg.id, -32603, e instanceof Error ? e.message : String(e));
  });
}
